const API_BASE_URL = "http://localhost:5000/api"; // ajuste conforme seu backend

export default API_BASE_URL;
