import React from 'react';

const Home = () => {
  return (
    <div>
      <h1>Bem-vindo ao Sistema de Propostas</h1>
      <p>Este é o painel inicial onde você pode gerenciar suas propostas, clientes e mais.</p>
    </div>
  );
};

export default Home;
